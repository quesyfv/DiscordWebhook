import customtkinter as ctk
import requests
import socket

# Initialize the app
root = ctk.CTk()
root.title("Quesy GUI")
root.geometry("400x600")

# Set default appearance mode and color theme
ctk.set_appearance_mode("light")  # Default to light mode
ctk.set_default_color_theme("blue")

# Function to toggle between light and dark modes
def toggle_theme():
    if ctk.get_appearance_mode() == "Light":
        ctk.set_appearance_mode("Dark")
    else:
        ctk.set_appearance_mode("Light")

# Function to open Webhook Messenger
def open_webhook_messenger():
    webhook_window = ctk.CTkToplevel(root)
    webhook_window.geometry("350x300")
    webhook_window.title("Webhook Messenger")

    def send_message():
        webhook_url = webhook_entry.get()
        message = message_entry.get()
        count = count_entry.get()

        if not webhook_url or not message or not count.isdigit():
            result_label.configure(text="Please fill all fields correctly.", text_color="red")
            return

        payload = {"content": message}
        count = int(count)

        for _ in range(count):
            response = requests.post(webhook_url, json=payload)
            if response.status_code != 204:
                result_label.configure(text=f"Error: {response.status_code}", text_color="red")
                return

        result_label.configure(text=f"Message sent {count} times!", text_color="green")

    ctk.CTkLabel(webhook_window, text="Webhook URL").pack(pady=5)
    webhook_entry = ctk.CTkEntry(webhook_window, width=300)
    webhook_entry.pack(pady=5)

    ctk.CTkLabel(webhook_window, text="Message").pack(pady=5)
    message_entry = ctk.CTkEntry(webhook_window, width=300)
    message_entry.pack(pady=5)

    ctk.CTkLabel(webhook_window, text="Count").pack(pady=5)
    count_entry = ctk.CTkEntry(webhook_window, width=300)
    count_entry.pack(pady=5)

    send_btn = ctk.CTkButton(webhook_window, text="Send Message", command=send_message)
    send_btn.pack(pady=10)

    result_label = ctk.CTkLabel(webhook_window, text="", font=("Helvetica", 12))
    result_label.pack(pady=5)

# Function to open IP Scanner
def open_ip_scanner():
    ip_scanner_window = ctk.CTkToplevel(root)
    ip_scanner_window.geometry("350x300")
    ip_scanner_window.title("IP Scanner")

    def scan_ports():
        ip = ip_entry.get()
        open_ports = []

        for port in range(1, 1025):
            try:
                with socket.create_connection((ip, port), timeout=1):
                    open_ports.append(port)
            except:
                continue

        result_label.configure(text=f"Open Ports: {open_ports if open_ports else 'None'}")

    ctk.CTkLabel(ip_scanner_window, text="IP Address").pack(pady=5)
    ip_entry = ctk.CTkEntry(ip_scanner_window, width=300)
    ip_entry.pack(pady=5)

    scan_btn = ctk.CTkButton(ip_scanner_window, text="Scan Ports", command=scan_ports)
    scan_btn.pack(pady=10)

    result_label = ctk.CTkLabel(ip_scanner_window, text="", font=("Helvetica", 12))
    result_label.pack(pady=5)

# Function to show credits
def show_credits():
    credits_window = ctk.CTkToplevel(root)
    credits_window.geometry("350x200")
    credits_window.title("Credits")

    credits_text = (
        "CREDITS\n"
        "Developed by Quesy\n"
        "TikTok: @quesyfv\n"
    )

    ctk.CTkLabel(credits_window, text=credits_text, font=("Helvetica", 14), justify="left").pack(pady=20)

# Header
header_label = ctk.CTkLabel(root, text="Welcome to Quesy GUI", font=("Helvetica", 24))
header_label.pack(pady=20)

# Buttons to open each tool
ctk.CTkButton(root, text="Open Webhook Messenger", command=open_webhook_messenger).pack(pady=10)
ctk.CTkButton(root, text="Open IP Scanner", command=open_ip_scanner).pack(pady=10)
ctk.CTkButton(root, text="Show Credits", command=show_credits).pack(pady=10)

# Dark/Light mode toggle button
theme_toggle_btn = ctk.CTkButton(root, text="Toggle Dark/Light Mode", command=toggle_theme)
theme_toggle_btn.pack(pady=20)

# Footer
footer_label = ctk.CTkLabel(root, text="Made by Quesy", font=("Helvetica", 12))
footer_label.pack(side="bottom", pady=20)

# Run the app
root.mainloop()
